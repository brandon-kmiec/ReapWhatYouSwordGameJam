Art by Aaron Rodriguez
Programming by Brandon Kmiec @ CSU Sacramento
Custom Game Engine provided to computer science students by Prof. Phillips @ CSU Sacramento
Free to Use Audio by SoundsForStories @ YouTube (https://youtu.be/qTMn-ixmjdk?si=Sxowc8kENjNdu_fM)
Game over audio made using Chrome Music Lab


To run the game, take the GameJam01 folder and open in any IDE (IntelliJ, Eclipse, etc.) of your choice that can run
Java 8 or above.

Reap What You Sword is a fantasy visual novel game that can be played entirely with the mouse.  Left mouse click to
interact with the game.  Press the Esc key on the keyboard to exit the game.

Due to time constraints, the South, East, and West levels only display the sprites but no dialogue. The North level and
the TitleScreen are fully functional and can be interacted with.